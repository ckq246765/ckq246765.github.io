package com.zcph.oaonline.mapper2;

import com.zcph.oaonline.entity.News;
import com.zcph.oaonline.util.MyMapper;

public interface NewsMapper extends MyMapper<News> {
}