package com.zcph.oaonline.mapper;

import com.zcph.oaonline.entity.UserLoginTable;
import com.zcph.oaonline.util.MyMapper;

public interface UserLoginTableMapper extends MyMapper<UserLoginTable> {
}